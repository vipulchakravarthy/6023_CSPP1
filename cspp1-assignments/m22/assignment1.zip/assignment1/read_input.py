'''
Write a python program to read multiple lines of text input and store the input into a string.
'''

def main():
    pass

if __name__ == '__main__':
    main()
